
package edu.ipn.cecyt9.calculadora;

/**
 * 
 *@author:  José Salinas y Luis Solano 
 * @version:  1.0 
 * @date: 06-09-2015 
 */
/**
 * 
 * @author José Salinas y Luis Solano 
 * 
 */
public class CalculadoraMain {
 public static void main(String[] args) {
		Calculadora calculadora = new Calculadora();
		calculadora.setVisible(true);
	}   
}
